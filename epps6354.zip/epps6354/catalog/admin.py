from django.contrib import admin
from .models import Property_Crime
from .models import Violent_Crime

admin.site.register(Property_Crime)
admin.site.register(Violent_Crime)

