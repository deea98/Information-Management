from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name='index'),
    path('pc', views.pc, name='pc'),
    path('vc', views.vc, name='vc'),
    path('static_image', views.static_image, name='static_image'),
    path('violentfrequency', views.violentfrequency, name='violentfrequency'),
    path('propertyfrequency', views.propertyfrequency, name='propertyfrequency'),
    path('violentcity', views.violentcity, name='violentcity'),
    path('farmers_branch', views.farmers_branch, name='farmers_branch'),
]

