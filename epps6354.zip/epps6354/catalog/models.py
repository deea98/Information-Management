from django.db import models

class Property_Crime(models.Model):
    p_id = models.CharField(primary_key=True, max_length=20)
    city_name = models.CharField(max_length=15, blank=True, null=True)
    p_type = models.CharField(max_length=15, blank=True, null=True)
    frequency = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'property_crime'

class Violent_Crime(models.Model):
    v_id = models.CharField(primary_key=True, max_length=20)
    city_name = models.CharField(max_length=15, blank=True, null=True)
    v_type = models.CharField(max_length=15, blank=True, null=True)
    frequency = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'violent_crime'