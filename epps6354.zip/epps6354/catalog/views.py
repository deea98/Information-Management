from django.shortcuts import render

from django.http import HttpResponse
from django.template import loader
from .models import Property_Crime
from .models import Violent_Crime
from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    return HttpResponse("Hello, world. You're at the catalog index.")
def pc(request):
    property_crimes = Property_Crime.objects.all()
    template = loader.get_template('catalog/pc.html')
    context = {
        'property_crime_list': property_crimes,
    }
    return HttpResponse(template.render(context, request))
def vc(request):
    violent_crimes = Violent_Crime.objects.all()
    template = loader.get_template('catalog/vc.html')
    context = {
        'violent_crime_list': violent_crimes,
    }
    return HttpResponse(template.render(context, request))
def static_image(request):
    template = loader.get_template('catalog/static_image.html')
    context = {}
    return HttpResponse(template.render(context, request))
def violentfrequency(request):
    template = loader.get_template('catalog/violentfrequency.html')
    context = {}
    return HttpResponse(template.render(context, request))
def propertyfrequency(request):
    template = loader.get_template('catalog/propertyfrequency.html')
    context = {}
    return HttpResponse(template.render(context, request))
def violentcity(request):
    template = loader.get_template('catalog/violentcity.html')
    context = {}
    return HttpResponse(template.render(context, request))
def farmers_branch(request):
    template = loader.get_template('catalog/farmers_branch.html')
    context = {}
    return HttpResponse(template.render(context, request))